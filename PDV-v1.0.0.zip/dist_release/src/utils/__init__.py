"""
Módulo de funções utilitárias
"""
