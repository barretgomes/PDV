"""
Módulo de interface gráfica
"""
